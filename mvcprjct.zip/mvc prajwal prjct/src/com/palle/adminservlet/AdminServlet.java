package com.palle.adminservlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.palle.dao.Dao;
import com.palle.student.Student;

/**
 * Servlet implementation class AdminServlet
 */
@WebServlet("/login")
public class AdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		/*String sn = request.getParameter("sname");
		String sb = request.getParameter("sub");
		Student ss = new Student(sn,sb);
		Dao d = new Dao();
		//d.insert(ss);*/


		String email = request.getParameter("email");
		String pass= request.getParameter("pw");
		Student ss = new Student(email,pass);
		Dao d = new Dao();
		if(d.adminLogin(ss))
		{
			RequestDispatcher dp =request.getRequestDispatcher("Admnhm.jsp");
			dp.forward(request,response);
		}
		
		
		else
		{
			out.println("<script type=\"text/javascript\">");
			   out.println("alert('Username or Password Incorrect,Enter correct credential');");
			   out.println("location='Admin.html';");
			   out.println("</script>");
		}
		
		
		
		
	}

}
