package com.palle.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.jasper.tagplugins.jstl.core.Out;

import com.palle.student.InsertBean;
import com.palle.student.Student;

public class Dao
{
	
	
	public boolean adminLogin( Student s )
	{
		boolean validate = false;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/college", "root", "admin");	
			String qry="select * from cadmin where email=? and pw=?";
		      PreparedStatement p = con.prepareStatement(qry);
		      p.setString(1, s.getEmail());
		      p.setString(2, s.getPw());
		     
		      ResultSet rs =  p.executeQuery();
		      validate = rs.next();
		      rs.close();
		      p.close();
			  con.close();
			    	
		      } catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			 } catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			 }
		
		      return validate;

			
	}
   public void insert(InsertBean i)
   {
	   try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/college", "root", "admin");
	        //Statement s = con.createStatement();
	        String q = "insert into student(sname,sub)values(?,?)";

			PreparedStatement p = con.prepareStatement(q);
	        p.setString(1, i.getSnam());
	        p.setString(2, i.getSub());
	       
           p.executeUpdate();
          
	        p.close();
	        con.close();
		
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
   }
   
  
   
}
