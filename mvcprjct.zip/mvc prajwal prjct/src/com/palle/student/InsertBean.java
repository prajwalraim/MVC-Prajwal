package com.palle.student;

public class InsertBean 
{
	private String snam;
    private String sub;
    
    public InsertBean() {
		super();
	}


	public String getSnam() {
		return snam;
	}


	public void setSnam(String snam) {
		this.snam = snam;
	}


	public String getSub() {
		return sub;
	}


	public void setSub(String sub) {
		this.sub = sub;
	}


	public InsertBean(String snam, String sub) {
		super();
		this.snam = snam;
		this.sub = sub;
	}

}
